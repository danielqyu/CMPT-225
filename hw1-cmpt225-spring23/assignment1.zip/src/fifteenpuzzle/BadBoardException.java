package fifteenpuzzle;

public class BadBoardException extends Exception {

	private static final long serialVersionUID = 1L;

	public BadBoardException(String message) {
		super(message);
	}
}
